// Function to parse query parameters from URL
function getQueryVariable(variable) {
    const query = window.location.search.substring(1);
    const vars = query.split('&');
    for (let i = 0; i < vars.length; i++) {
        const pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) === variable) {
            return decodeURIComponent(pair[1]);
        }
    }
    return null;
}

// Get the selected semester from the URL

// Function to fetch and display students of the selected semester
function fetchSemesterStudents() {
    // Sample data from the database (replace this with your actual data)
    const studentData = [
        { usn: '123', name: 'John Doe' },
        { usn: '456', name: 'Jane Smith' },
        { usn: '789', name: 'Bob Johnson'},
        // Add more student data as needed
    ];

    // Display the students in the table
    const attendanceTableBody = document.querySelector('#attendanceTable tbody');
    studentData.forEach(student => {
        
            const row = attendanceTableBody.insertRow();
            row.id = student.usn;

            const usnCell = row.insertCell(0);
            const nameCell = row.insertCell(1);
            const attendanceCell = row.insertCell(2);

            usnCell.textContent = student.usn;
            nameCell.textContent = student.name;

            // Create radio buttons for "Present" and "Absent"
            const presentRadio = document.createElement('input');
            presentRadio.type = 'radio';
            presentRadio.name = `attendance_${student.usn}`;
            presentRadio.value = 'present';
            presentRadio.id = `present_${student.usn}`;

            const absentRadio = document.createElement('input');
            absentRadio.type = 'radio';
            absentRadio.name = `attendance_${student.usn}`;
            absentRadio.value = 'absent';
            absentRadio.id = `absent_${student.usn}`;

            // Create labels for radio buttons
            const presentLabel = document.createElement('label');
            presentLabel.textContent = 'Present';
            presentLabel.setAttribute('for', `present_${student.usn}`);

            const absentLabel = document.createElement('label');
            absentLabel.textContent = 'Absent';
            absentLabel.setAttribute('for', `absent_${student.usn}`);

            // Append radio buttons and labels to the "Attendance" cell
            attendanceCell.appendChild(presentRadio);
            attendanceCell.appendChild(presentLabel);
            attendanceCell.appendChild(document.createElement('br')); // Add line break
            attendanceCell.appendChild(absentRadio);
            attendanceCell.appendChild(absentLabel);
        }
    )};

