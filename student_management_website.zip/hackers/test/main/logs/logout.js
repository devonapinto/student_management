function logout() {
    
    window.location.href = '../logs/index.html';
  }
  