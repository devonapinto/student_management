document.getElementById('toggleMenu').addEventListener('click', function() {
  toggleSidebar();
});

// Add event listeners to close the sidebar when a menu item is clicked
const menuItems = document.querySelectorAll('.sidebar a');
menuItems.forEach(item => {
  item.addEventListener('click', function() {
      toggleSidebar();
  });
});

function toggleSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const body = document.querySelector('body');

  if (sidebar.style.width === '250px') {
      sidebar.style.width = '0';
      body.style.marginLeft = '0';
  } else {
      sidebar.style.width = '250px';
      body.style.marginLeft = '250px';
  }
}