(function($) {  
jQuery(document).ready(function(){$("#menuzord").menuzord({align: "left"});});
$(document).ready(function() {
  $('#backTop').backTop({
    'position' : 15,
    'speed' : 500,
    'color' : 'red',
  });
  
});

AOS.init({
    duration: 800,
    once: true,
    easing: "ease-in-out"
  });

$(document).ready(function() {
var stickyNavTop = $('#site_header').offset().top;
 
var stickyNav = function(){
var scrollTop = $(window).scrollTop();
      
if (scrollTop > stickyNavTop) { 
    $('#site_header').addClass('sticky');
} else {
    $('#site_header').removeClass('sticky'); 
}
};
 
stickyNav();
 
$(window).scroll(function() {
    stickyNav();
});
});

})(jQuery);

var swiper1 = new Swiper('.swiper1', {
     slidesPerView: 1, spaceBetween: 0, 
     loop: true, 
     speed: 3000,
     effect: 'fade',
     autoplay: {
        delay: 4500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination1',
        clickable: true, 
      },
      navigation: {
        nextEl: '.swiper1-next',
        prevEl: '.swiper1-prev',
      },
      breakpoints: {360: { slidesPerView: 1, spaceBetween: 0},
        480: {slidesPerView: 1, spaceBetween: 0},
        640: {slidesPerView: 1, spaceBetween: 0}
      },
    });

swiper1.on('slideChangeTransitionEnd', function () {
  $('.banner_wrapper').addClass('banner_vis'); 
  $('.site_banner_title').addClass('animate__animated animate__slideInRight'); 
  $('.site_banner_desc').addClass('animate__animated animate__slideInLeft');
});
swiper1.on('slideNextTransitionStart', function () {
  $('.banner_wrapper').removeClass('banner_vis');
  $('.site_banner_title').removeClass('animate__animated animate__slideInRight'); 
  $('.site_banner_desc').removeClass('animate__animated animate__slideInLeft');  
  AOS.init();
});

var swiper2 = new Swiper('.swiper2', {
     slidesPerView: 1, spaceBetween: 0, 
     loop: true, 
     autoplay: {
        delay: 4500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination2',
        clickable: true, 
      },
      navigation: {
        nextEl: '.swiper2-next',
        prevEl: '.swiper2-prev',
      },
      breakpoints: {360: { slidesPerView: 1, spaceBetween: 0},
        480: {slidesPerView: 1, spaceBetween: 0},
        640: {slidesPerView: 1, spaceBetween: 0}
      },
    });